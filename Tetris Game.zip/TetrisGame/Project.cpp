/*
Name: Muhammad Haider Bukhari
Section CS-K
Roll NO 22I-0980
Project
*/


/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You don't need to change anything in the driver code/main function except the part(s) where instructed.
 * You are expected to define your functionalities in the "functionality.h" header and call them here in the instructed part(s).
 * The game is started with a small box, you need to create other possible in "pieces.h" file in form of array.
    E.g., Syntax for 2 pieces, each having four coordinates -> int Pieces[2][4];
 * Load the images into the textures objects from img directory.
 * Don't make any changes to the "utils.h" header file except for changing the coordinate of screen or global variables of the game.
 * SUGGESTION: If you want to make changes in "utils.h", do it once you complete rest of the functionalities.
 * TIP: You can study SFML for drawing scenes, sprites and window.
 * */
int BLOCKS[9][4] = {{2, 4, 6, 8}, {0, 1, 2, 4}, {0, 1, 3, 5}, {0, 1, 2, 3}, {0, 2, 3, 5}, {1, 2, 3, 5}, {0, 2, 3, 4}, {1, 1, 1, 1}};
int tomarks = 0;
/////////////////////////Including Predefined Libraries//////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <sstream>
#include <time.h>
#include "utils.h"
#include "pieces.h"
#include "functionality.h"
///////////////////////////////////////////////////////////////////////////////////////////////////

using namespace sf;
using namespace std;
void myftn();

int main()
{
    float delay = 0.6;
    static int myname = 0;
    static int level = 1;
///////////////////////////Taking Input so that to do file Handelling///////////////////////////////////
    string array[1000];
    cout << "Enter the player Name: ";
    cin >> array[myname];
/////////////////////////////////////////Reading File/////////////////////////////////////////////
    fstream file("name.txt", ios::app);
    file << array[myname] << " " << endl;
    file.close();

    myname++;
    Font font;
/////////////////////////////////Playing Tetris Audio at Back/////////////////////////////////////
    if (!font.loadFromFile("PlayfairDisplay-Regular.otf"))
    {
        cout << "Not loading";
    }

    int arr[100];
    srand(time(0));
    int playagain1 = 0;
/////////////////////////////////////Defining WIndow Size as 480*500///////////////////////////////
    RenderWindow window(VideoMode(480, 500), title);
    while (true)
    {

        playagain1 = 0;
////////////////////////////////////Displaying the Main Menu/////////////////////////////////////
        while (window.isOpen())
        {
            Texture obj7;
            obj7.loadFromFile("./img/Tetris_Main.png");
            Sprite ss(obj7);

            for (float i = 0; i < 10000; i++)
            {
                window.draw(ss);
                window.display();
                i -= 0.5;
            }
            break;
        }
///////////////////////////////////////////////////////////////////////////////////////////////////
        while (window.isOpen())
        {
            int breaking = 0;

            Texture obj7;
            obj7.loadFromFile("./img/Tetris_Main.png");
            Sprite ss(obj7);

            int playincrement = 15;

            SoundBuffer buffer;
            if (!buffer.loadFromFile("song.ogg"))
            {
                cout << "error";
            }

            Sound sound;
            sound.setBuffer(buffer);
            sound.setVolume(6);
            sound.play();
            Texture object;
            object.loadFromFile("background.jpeg");
            Sprite spritess(object);

            window.draw(spritess);
            int playagain = 0;
            window.display();
///////////////////////////////////Creating Event functio so that user can make inputwith respect 
///////////////////////////////////to the Menu Bar/////////////////////////////////////////// 
            Event event;
            while (window.pollEvent(event))
            {

                switch (event.type)
                {
                    char arr[100];
                case ::Event::KeyPressed:

                    int final = 0;
////////////////////////////////////E Keyboard word display highest Marks among player played//////
                    if (event.key.code == Keyboard::E)
                    {

                        char alpha[50];
                        int inc = 0;
                        int count = 0;

                        string line;
                        ifstream file("Haider.txt");

                        while (getline(file, line))
                        {
                            count++;
                        }
/////////////////////////////////input files///////////////////////////////////////////////////
                        ifstream infile("Haider.txt");
                        ifstream namesection("name.txt");

                        int arr[count];

                        for (int i = 0; i < count; i++)
                        {
                            infile >> arr[i];
                        }
                        for (int i = 0; i < count; i++)
                        {
                            namesection >> array[i];
                        }

                        infile.close();
///////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////Displaying the Input stream text////////////////////////////////////
                        
                        Text htex, hrtex, hhrtex;
                        window.clear(Color::White);

                        htex.setFont(font);
                        hrtex.setFont(font);
                        hhrtex.setFont(font);

                        htex.setCharacterSize(23.5);
                        hrtex.setCharacterSize(26.5);
                        hhrtex.setCharacterSize(23.5);

                        htex.setFillColor(Color::Blue);
                        hrtex.setFillColor(Color::Red);
                        hhrtex.setFillColor(Color::Green);

                        htex.setStyle(Text::Bold);
                        hrtex.setStyle(Text::Bold);
                        hhrtex.setStyle(Text::Bold);

                        hrtex.setString("Previous Game PLayers Highest Scores: ");

///////////////////////////////////Creating Bubble Sort to display the highest first//////////////
                        for (int i = 0; i < count - 1; i++)
                        {
                            for (int k = 0; k < count - 1 - i; k++)
                            {
                                if (arr[k] < arr[k + 1])
                                {
                                    int temp = arr[k];
                                    string temperory = array[k];
                                    arr[k] = arr[k + 1];
                                    array[k] = array[k + 1];
                                    arr[k + 1] = temp;
                                    array[k + 1] = temperory;
                                }
                            }
                        }
///////////////////////////////////////////////////////////////////////////////////////////////////
                        int zz = 0;
                        while (true)
                        {
                            if (event.key.code == Keyboard::Escape)
                            {
                                zz++;
                                break;
                            }
                            window.clear(Color::White);
                            hrtex.setPosition(10, 10);
                            window.draw(hrtex);
                            if (event.key.code == Keyboard::Escape)
                            {
                                window.close();
                            }

                            for (int i = 0; i < count; i++)
                            {

                                int j = arr[i];
                                htex.setString(to_string(j));
                                htex.setPosition(40, 45 + 42 * i);
                                window.draw(htex);

                                hhrtex.setString(array[i]);
                                hhrtex.setPosition(80, 45 + 42 * i);
                                window.draw(hhrtex);
                                if (event.key.code == Keyboard::Escape)
                                {
                                    window.close();
                                }
                            }
                            window.display();
                        }
                    }
                    if (final != 0)
                    {
                        break;
                    }
////////////////////////////A is the main playing part of program//////////////////////////////////
                    else if (event.key.code == Keyboard::A)
                    {
////////////////////////////Creating Objects and Sprites////////////////////////////////////////////

                        Texture obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj9;

                        obj1.loadFromFile("./img/tiles.png");
                        obj2.loadFromFile("./img/background.png");
                        obj3.loadFromFile("./img/frame.png");
                        obj4.loadFromFile("./img/shadow.jpeg");
                        obj5.loadFromFile("./img/prop2.jpg");
                        obj6.loadFromFile("./img/tiles.png");
                        obj9.loadFromFile("./img/check1.jpeg");

                        Sprite shadow(obj4), haider(obj5), marks(obj7), iot(obj9);

                        Sprite alphabeta(obj2);

                        Sprite sprite(obj1), sprote(obj1), background(obj2), newsprite(obj6), frame(obj3);
                        Sprite tetris_main(obj7);
                        Text display, display1, display2;
                        display.setCharacterSize(28.5);
                        display.setFillColor(Color::White);
                        display.setStyle(Text::Bold);
                        display.setPosition(59, 50);

                        display1.setCharacterSize(24.5);
                        display1.setFillColor(Color::White);
                        display1.setStyle(Text::Bold);
                        display1.setPosition(99, 50);

                        display2.setCharacterSize(24.5);
                        display2.setFillColor(Color::White);
                        display2.setStyle(Text::Bold);
                        display2.setPosition(159, 50);
                        for (float i = 0; i < 10000; i++)
                        {
///////////////////////////Level will be inremented when the game end and new start/////////////////////////////////////

                            window.draw(alphabeta);
                            window.draw(frame);
                            display.setFont(font);
                            display.setString("Level " + to_string(level));
                            display1.setString("Mission");
                            display2.setString("Complete Maximum Rows");
                            window.draw(display);
                            window.draw(display1);
                            window.draw(display2);
                            window.display();
                            i -= 0.8;
                            window.clear();
                        }
///////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////Creating Variable for the whole program////////////////////////////////

                        int delta_x = 0,
                            count = 0, rotation = 0, countss = 0, move = 0, counti = 0, cont = 0, calculate = 0, nextrotation = 0;
                        float timer = 0;
                        bool rotate = 0;
                        Clock clock;
                        int count_to_rotate = 1, right = 0, jeo = 0, didi;
                        int size = 4, rows = 20, chaha = 0, counssss = 0, downwards = 0;
                        int arr[20] = {0};
                        int zomb = 0;

                        int alpha_1[100][100] = {0}, gameGridss[100][100] = {0};
                        int arr1[10] = {0};
                        int alpha = 0, increment = 0, zeeta2 = -1, zeeta = 0, zeeta1 = 0;
                        int colorNum = rand() % 7 + 1;
                        int temp1 = rand() % 7 + 1;
                        int ColorName = 0, score = 0;
                        int GridColor[100][100], newvariable = 0;
                        int bombcolor = -1;
                        int cosmat = 0, checkit = 0;
                        int fixed = 0, nanofixed = 0, bep = 0, block = 0, rotationno = 0, rotation1 = 0, rotation4 = 0, rotation2 = 0, rotation0 = 0;
                        int n = rand() % 8, countious = 0, countpp = 0;
                        int temp = rand() % 8;
                        block = n;
///////////////////////////////////////////////////////////////////////////////////////////////////
                        
////////////////////////Passing the block shape to the row and column comp///////////////////////////////
                        for (int i = 0; i < 4; i++)
                        {
                            point_1[i][0] = BLOCKS[n][i] % 2;
                            point_1[i][1] = BLOCKS[n][i] / 2;
                        }

                        for (int i = 0; i < 4; i++)
                        {
                            point_3[i][0] = BLOCKS[temp][i] % 2;
                            point_3[i][1] = BLOCKS[temp][i] / 2;
                        }
///////////////////////////////////////////////////////////////////////////////////////////////////
                        while (window.isOpen())
                        {
                            rotation = 0;
                            float time = clock.getElapsedTime().asSeconds();
                            clock.restart();
                            timer += time;

                            Event e;

                            while (window.pollEvent(e))
                            {
//////////////////////////////Creating Event of Key Pressed ///////////////////////////////////////
                                if (e.type == Event::Closed)

                                    window.close();

                                if (e.type == Event::KeyPressed)
                                {
                                    cosmat = 0;
//////////////////////////////////Up will rotate the block//////////////////////////////////
                                    if (e.key.code == Keyboard::Up)
                                    {
                                        static int beta = 1;
                                        rotate = true;
                                        // rotation_move(n, count_to_rotate, downwards, calculate, zeeta, zeeta1, zeeta2);
                                        beta++;
                                        if (n == 0)
                                        {
                                            rotation0++;
                                            rotation0s(rotation0);
                                        }
                                        if (n == 1)
                                        {
                                            rotation1++;
                                            rotation1s(rotation1);
                                        }
                                        if (n == 2)
                                        {
                                            rotation2++;
                                            rotation2s(rotation2);
                                        }
                                        if (n == 4)
                                        {
                                            rotation4++;
                                            rotation4s(rotation4);
                                        }
                                        int alpha = 0;

                                        if (n == 5)
                                        {
                                            inbetween(beeta);
                                            inbetween1(beeta);
                                            nextrotation++;
                                            rotation5s(nextrotation);
                                        }
                                        else if (n == 6)
                                        {
                                            rotationno++;
                                            int countoo = 0;
                                            cosmat++;
                                            rotation6s(rotationno);
                                        }
                                        int check = 0;
                                        check_grid(check);
                                    }

//////////////////////////////////////////Moving Left//////////////////////////////////////////////
                                    else if (e.key.code == Keyboard::Left)
                                    {
                                        cosmat--;

                                        if (n == 7)
                                        {
                                            continue;
                                        }
                                        delta_x = -1;

                                        for (int i = 0; i < 4; i++)
                                        {
                                            point_1[i][0] += delta_x;
                                        }
                                        zeeta1++;
                                        inbetween(beeta);
                                    }
//////////////////////////////////////////Moving Right//////////////////////////////////////////////

                                    else if (e.key.code == Keyboard::Right)
                                    {
                                        if (n == 7)
                                        {
                                            continue;
                                        }
                                        calculate++;

                                        right++;
                                        zeeta1--;
                                        delta_x = 1;
                                        for (int i = 0; i < 4; i++)
                                        {
                                            point_1[i][0] += delta_x;
                                        }
                                        inbetween1(beeta);
                                    }
/////////////////////////////Dealing with spaces and other keywords///////////////////////////////////

                                    else if (e.key.code == Keyboard::Space)
                                    {
                                        delay = 0.0001;
                                    }
                                    else if (e.key.code == Keyboard::D)
                                    {
                                        window.draw(spritess);
                                        window.display();
                                    }

                                    else if (e.key.code == Keyboard::A)
                                    {
                                        window.draw(spritess);
                                        window.display();
                                    }

                                    else if (e.key.code == Keyboard::B)
                                    {
                                        newvariable++;
                                    }

                                    if (newvariable != 0)
                                    {

                                        for (int i = 0; 1; i++)
                                        {
                                            int x = 0;
                                            Event b;
                                            while (window.pollEvent(b))
                                            {
                                                int j = 0;
                                                if (b.type == Event::KeyPressed)
                                                {
                                                    if (b.key.code == Keyboard::C)
                                                    {

                                                        newvariable = 0;
                                                        j++;
                                                        x++;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        continue;
                                                    }
                                                }
                                                if (j != 0)
                                                {
                                                    break;
                                                }
                                            }
                                            if (x != 0)
                                            {
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            if (playagain != 0)
                            {
                                break;
                            }
                            if (breaking != 0)
                            {
                                break;
                            }
///////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////Crating time dialiation//////////////////////////////////////////////

                            if (Keyboard::isKeyPressed(Keyboard::Down))
                            {
                                if (n == 7)
                                {
                                    delay = 0.08;
                                }
                                delay = 0.1;
                            }
/////////////////////////////Grid check so thet the box cannot come out of Grid////////////////////////////////


                            gridcheck_back();
                            gridcheck_front();
//////////////////////////////////////////Shadow on the grid//////////////////////////////////////////////

                            for (int i = 0; i < 4; i++)
                            {
                                point_5[i][0] = point_1[i][0];
                                point_5[i][1] = point_1[i][1];
                            }
                            while (pass())
                            {
                                for (int i = 0; i < 4; i++)
                                {
                                    point_5[i][1] += 1;
                                }
                            }
///////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////if delay is less then time//////////////////////////////////////////////

                            if (timer > delay)
                            {
                                for (int i = 0; i < 4; i++)
                                {
                                    point_2[i][0] = point_1[i][0];
                                    point_2[i][1] = point_1[i][1];
                                    point_1[i][1] += 1;
                                    zeeta++;
                                }

                                downwards++;
                                // shadow(n, BLOCKS, timer);

                                if (!anamoly())
                                {
//////////////////////////////Passing the position of Grid as it's Color Number///////////////////////////////

                                    for (int i = 0; i < 4; i++)
                                    {
                                        gameGrid[point_2[i][1]][point_2[i][0]] = colorNum;
                                    }
//////////////////////////////////////////Up comming Box Logic//////////////////////////////////////////////

                                    n = temp;

                                    block = n;

                                    if (n == 7)
                                    {
                                        int j = rand() % 10;
                                        for (int i = 0; i < 4; i++)
                                        {

                                            point_1[i][0] = j;
                                        }
                                    }

                                    temp = rand() % 8;

                                    colorNum = temp1;

                                    temp1 = rand() % 7 + 1;

                                    playincrement--;

                                    delay = 0.1;
//////////////////////////////////////////Output stream in file handelling//////////////////////////////////////////////
//////////////////////////////////////By passing the score in the text file////////////////////

                                    if (playincrement == -1)
                                    {
                                        fstream file("Haider.txt", ios::app);
                                        file << score << " " << endl;
                                        level++;
                                        file.close();
//////////////////////////////////////////Moving Left//////////////////////////////////////////////

//////////////////////////////////////////Displaying the last Menu//////////////////////////////////////////////

                                        while (true)
                                        {
                                            Text htex, hrtex;
                                            window.clear();
                                            window.draw(background);
                                            htex.setFont(font);
                                            hrtex.setFont(font);
                                            htex.setCharacterSize(23.5);

                                            hrtex.setCharacterSize(23.5);
                                            htex.setFillColor(Color::White);
                                            int zx = 0;
                                            hrtex.setFillColor(Color::White);
                                            htex.setStyle(Text::Bold);
                                            hrtex.setStyle(Text::Bold);

                                            htex.setString("Press Enter to play The Game");
                                            hrtex.setString("else press Escape to exit");

                                            htex.setPosition(50, 100);
                                            hrtex.setPosition(53, 160);
                                            window.draw(htex);
                                            window.draw(hrtex);
                                            window.display();
                                            Event alpha;
                                            while (window.pollEvent(alpha))
                                            {
                                                if (alpha.key.code == Keyboard::Enter)
                                                {
                                                    playagain++;
                                                    break;
                                                }
                                                else if (alpha.key.code == Keyboard::Escape)
                                                {
                                                    playagain1 = 2;
                                                    window.close();
                                                }
                                            }
                                            if (playagain != 0 || playagain1 == 2)
                                            {
                                                break;
                                            }
                                        }
                                        if (playagain != 0)
                                        {
                                            break;
                                        }
                                    }
                                    if (n == 7)
                                    {
                                        bombcolor = colorNum;
                                    }
//////////////////////////////////////////Creating Variables//////////////////////////////////////////////


                                    inbetween(beeta);
                                    inbetween1(beeta);
                                    cosmat = 0;
                                    rotationno = 0;
                                    countpp = 0;
                                    nextrotation = 0;
                                    rotation4 = 0;
                                    rotation1 = 0;
                                    checkit = 0;

                                    zeeta = 0;
                                    zeeta1 = 0;
                                    downwards = 0;
                                    right = 0;
                                    cont = 0;
                                    alpha = 0, increment = 0;
                                    delay = 0.4;
                                    zeeta2 = 0;
                                    newsprite.setPosition(200, 300);
////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////Displayinh the current value of points//////////////////////////////

                                    for (int i = 0; i < 4; i++)
                                    {
                                        newsprite.setTextureRect(IntRect(colorNum * 18, 0, 18, 18));
                                        newsprite.move(28, 31);
                                        window.draw(newsprite);
                                    }

                                    for (int i = 0; i < 4; i++)
                                    {
                                        point_1[i][0] = BLOCKS[n][i] % 2;
                                        point_1[i][1] = BLOCKS[n][i] / 2;
                                    }
                                    for (int i = 0; i < 4; i++)
                                    {
                                        point_3[i][0] = BLOCKS[temp][i] % 2;
                                        point_3[i][1] = BLOCKS[temp][i] / 2;
                                    }
                                    if (n == 7)
                                    {
                                        int alpha = rand() % 10 + 1;
                                        for (int i = 0; i < 4; i++)
                                        {
                                            point_1[i][0] = alpha;
                                        }
                                    }
                                }
///////////////////////////////////////////////////////////////////////////////////////////////////

                                timer = 0;
                            }

                            delta_x = 0;

                            Sprite();
                            window.clear(Color::White);
                            window.draw(background);

//////////////////////////////////////////For Original Boxes//////////////////////////////////////////////

                            for (int i = 0; i < M; i++)
                            {
                                for (int j = 0; j < N; j++)
                                {
                                    if (gameGrid[i][j] == 0)
                                        continue;

                                    sprite.setTextureRect(IntRect(gameGrid[i][j] * 18, 0, 18, 18));
                                    sprite.setPosition(j * 18, i * 18);
                                    sprite.move(28, 31); // offset
                                    window.draw(sprite);
                                }
                            }

                            for (int i = 0; i < 4; i++)
                            {
                                sprite.setTextureRect(IntRect(colorNum * 18, 0, 18, 18));
                                sprite.setPosition(point_1[i][0] * 18, point_1[i][1] * 18);
                                sprite.move(28, 31);
                                window.draw(sprite);
                            }
////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////For Original Boxes//////////////////////////////////////////////

                            for (int i = 0; i < M; i++)
                            {
                                for (int j = 0; j < N; j++)
                                {
                                    if (gameGrid[i][j] == 0)
                                        continue;

                                    sprite.setTextureRect(IntRect(gameGrid[i][j] * 18, 0, 18, 18));
                                    sprite.setPosition(j * 18, i * 18);
                                    sprite.move(28, 31); // offset
                                    window.draw(sprite);
                                }
                            }

                            for (int i = 0; i < 4; i++)
                            {
                                sprite.setTextureRect(IntRect(colorNum * 18, 0, 18, 18));
                                sprite.setPosition(point_5[i][0] * 18, point_5[i][1] * 18);
                                sprite.move(28, 31);
                                window.draw(sprite);
                            }

////////////////////Creating the logic that if blok falls at the bottom of grid it will ////////////
////////////////////assign the specific value so that remove of the row become feasible./////////

                            int chounti = 0;
                            for (int i = 0; i < M; i++)
                            {
                                for (int j = 0; j < N - 4; j++)
                                {
                                    if (gameGrid[i][j] != 0)
                                    {
                                        if (gammma[i][j] == 1)
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            cout << i << " " << j << endl;
                                            GridColor[i][j] = colorNum;
                                            gammma[i][j] = 1;
                                            beeta[i][j] = 70;
                                            chounti++;
                                            fixed = i;
                                            nanofixed = j;
                                        }
                                    }
                                }
                            }
//////////////////////////////////////////////////////////////////////////////////////////////////
                            countpp++;
                            int count = 0, countsd = 1;
                            removing_lines(chounti, count, countsd, fixed, nanofixed);
////////////////////////////////////Judginmg either the block is a 4*4block or a bomb//////////
                            if (chounti == 4)
                            {
                                fixed = 0;
                                nanofixed = 0;

                                cont = 0;
                                int l = 0, p = 0, beta, increment = 0, zeeta;

                                int counto = 0;

                                for (int i = 0; i < 20; i++)
                                {
                                    counto = 0;
                                    for (int j = 0; j < 10; j++)
                                    {
                                        if (gammma[i][j] == 1)
                                        {
                                            counto++;
                                        }
                                    }

                                    check(counto, i, zeeta, beta, checkit);
                                }

                                cont = 0;
                            }
///////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////Checkit is the number of lines removed/////////////////////////////////
  //////////////////////////The marks will be awarded according to the criteria////////////////////
                            if (checkit == 1)
                            {
                                score += 10;
                                checkit = 0;
                            }
                            else if (checkit == 2)
                            {
                                score += 30;
                                checkit = 0;
                            }
                            else if (checkit == 3)
                            {
                                score += 60;
                                checkit = 0;
                            }
                            else if (checkit == 4)
                            {
                                score += 100;
                                checkit = 0;
                            }
                            chounti = 0;

                            iot.setPosition(336, 34);
                            window.draw(iot);
////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////Creating a new sprite of puzzle suggestion///////////////////////
                            Text mtext, htext;
                            mtext.setFont(font);
                            htext.setFont(font);
                            mtext.setCharacterSize(19.5);
                            htext.setCharacterSize(19.5);
                            mtext.setFillColor(Color::Blue);
                            htext.setFillColor(Color::Red);
                            mtext.setStyle(Text::Bold);
                            htext.setStyle(Text::Bold);

                            htext.setString("Next Puzzle");
                            htext.setPosition(345, 12);
                            window.draw(htext);
////////////////////////////////////////////////Here Temp is the shape of block either at position//
/////////////////////////////////////So can be adjusted/////////////////////////////////////////
                            if (temp == 0)
                            {
                                for (int i = 0; i < 4; i++)
                                {
                                    sprote.setTextureRect(IntRect(temp1 * 18, 0, 18, 18));
                                    sprote.setPosition(point_3[i][0] * 18, point_3[i][1] * 18);
                                    sprote.move(389, 30);
                                    window.draw(sprote);
                                }
                            }
///////////////////////////////////////////////////////////////////////////////////////////////
                            if (temp == 1)
                            {
                                for (int i = 0; i < 4; i++)
                                {
                                    sprote.setTextureRect(IntRect(temp1 * 18, 0, 18, 18));
                                    sprote.setPosition(point_3[i][0] * 18, point_3[i][1] * 18);
                                    sprote.move(382, 52);
                                    window.draw(sprote);
                                }
                            }
///////////////////////////////////////////////////////////////////////////////////////////////
                            if (temp == 2)
                            {
                                for (int i = 0; i < 4; i++)
                                {
                                    sprote.setTextureRect(IntRect(temp1 * 18, 0, 18, 18));
                                    sprote.setPosition(point_3[i][0] * 18, point_3[i][1] * 18);
                                    sprote.move(382, 57);
                                    window.draw(sprote);
                                }
                            }
///////////////////////////////////////////////////////////////////////////////////////////////
                            if (temp == 3)
                            {
                                for (int i = 0; i < 4; i++)
                                {
                                    sprote.setTextureRect(IntRect(temp1 * 18, 0, 18, 18));
                                    sprote.setPosition(point_3[i][0] * 18, point_3[i][1] * 18);
                                    sprote.move(385, 63);
                                    window.draw(sprote);
                                }
                            }
///////////////////////////////////////////////////////////////////////////////////////////////
                            if (temp == 4 || temp == 5 || temp == 6)
                            {
                                for (int i = 0; i < 4; i++)
                                {
                                    sprote.setTextureRect(IntRect(temp1 * 18, 0, 18, 18));
                                    sprote.setPosition(point_3[i][0] * 18, point_3[i][1] * 18);
                                    sprote.move(385, 54);
                                    window.draw(sprote);
                                }
                            }
///////////////////////////////////////////////////////////////////////////////////////////////
                            if (temp == 7)
                            {

                                mtext.setString("Bomb");
                                mtext.setPosition(372, 46);
                                window.draw(mtext);

                                for (int i = 0; i < 4; i++)
                                {
                                    sprote.setTextureRect(IntRect(temp1 * 18, 0, 18, 18));
                                    sprote.setPosition(point_3[i][0] * 18, point_3[i][1] * 18);
                                    sprote.move(372, 84);
                                    window.draw(sprote);
                                }
                            }
///////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////Displaying the Score acheived/////////////////////////////////

                            Text text, mytext, newa, newText, newText1;
                            text.setFont(font);
                            mytext.setFont(font);
                            newText.setFont(font);
                            newText1.setFont(font);

                            text.setCharacterSize(17.5);
                            mytext.setCharacterSize(24.5);
                            newText.setCharacterSize(17.5);
                            newText1.setCharacterSize(24.5);

                            text.setFillColor(Color::Red);
                            mytext.setFillColor(Color::Red);
                            newText.setFillColor(Color::Red);
                            newText1.setFillColor(Color::Red);

                            text.setStyle(Text::Bold);
                            mytext.setStyle(Text::Bold);
                            newText.setStyle(Text::Bold);
                            newText1.setStyle(Text::Bold);

                            text.setString("Total Turns Left");
                            newText.setString("Score");
                            mytext.setString("" + to_string(score));
                            newText1.setString("" + to_string(playincrement));

                            haider.setPosition(330, 300);
                            window.draw(haider);

                            haider.setPosition(330, 410);
                            window.draw(haider);

                            mytext.setPosition(380, 314);
                            window.draw(mytext);

                            text.setPosition(330, 382);
                            window.draw(text);

                            newText.setPosition(370, 267);
                            window.draw(newText);

                            newText1.setPosition(380, 425);
                            window.draw(newText1);

                            newsprite.setPosition(350, 350);

                            window.draw(newa);
                            //---The Final on Which Everything is Drawn Over is Loaded---//
                            window.draw(frame);

                            //---The Window that now Contains the Frame is Displayed---//

                            window.display();
                        }
                        if (playagain != 0)
                        {
                            break;
                        }
                        if (breaking != 0)
                        {
                            break;
                        }
                        return 0;
                    }
                    else if (event.key.code == Keyboard::Escape)
                    {
                        window.close();
                    }
                }

                if (event.key.code == Keyboard::D)
                {
                    window.close();
                }
            }
            if (playagain != 0)
            {
                if (playagain1 != 0)
                {
                    break;
                }
                window.clear();
/////////////////////////////After one game passed then shiffting to next past will be make zero///////////////////////////////////////////////
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        gameGrid[i][j] = 0;
                        gammma[i][j] = 0;
                        beeta[i][j] = 0;
                    }
                }
                break;
            }

            /// Add image to where we want;
        }
////////////////////////////Break is done to continue the whole process again////////////////////
        if (playagain1 != 0)
        {
            delay -= 0.2;

            break;
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////
}