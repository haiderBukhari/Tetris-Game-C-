/*
Name: Muhammad Haider Bukhari
Section CS-K
Roll NO 22I-0980
Project
*/

/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You need to define the required function in the part instructed here below.
 * Avoid making any unnecessary changes, particularly the ones you don't understand.
 * The different pieces should be defined using an array - uncomment the following code once you are done creating the array.
 * TIP: Understand thoroughly before getting started with coding.
 * */

//---Piece Starts to Fall When Game Starts---//

/////////////////////////////////////////////
///*** START CODING YOUR FUNTIONS HERE ***///
#include <iostream>
#include <SFML/Graphics.hpp>

using namespace std;
static int alpha = 0;
static int alpha2 = 0;

////////////////////////////Used to check weather it would not turns out from the left///////////
void tocheck()
{
    int i = 0;
    while(i<4)
    {
        if (gameGrid[i][1] < 0)
        {
            break;
        }
    }
}
////////////////////////////It is ued to check for the block to stuck within other block (Right)///////////

void inbetween1(int beeta[][100])
{
    int contioun = 0;
    for (int i = 0; i < 4; i++)
    {
        if (beeta[point_1[i][1]][point_1[i][0]] == 70)
        {
            contioun++;
        }
    }
    if (contioun != 0)
    {
        for (int i = 0; i < 4; i++)
        {
            point_1[i][0] -= 1;
        }
        contioun = 0;
    }
}
////////////////////////////It is ued to check for the block to stuck within other block (Left)///////////

void inbetween(int beeta[][100])
{
    int contioun = 0;
    for (int i = 0; i < 4; i++)
    {
        if (beeta[point_1[i][1]][point_1[i][0]] == 70)
        {
            contioun++;
        }
    }
    if (contioun != 0)
    {
        for (int i = 0; i < 4; i++)
        {
            point_1[i][0] += 1;
        }
        contioun = 0;
    }
}
////////////////////////////The block cant get out from the right side of the Grid///////////////

void gridcheck_front()
{
    int contioun = 0;
    for (int i = 0; i < 4; i++)
    {
        if (point_1[i][0] > 9)
        {
            contioun++;
        }
    }
    if (contioun != 0)
    {
        for (int i = 0; i < 4; i++)
        {
            point_1[i][0] -= 1;
        }
        contioun = 0;
    }
}
//////////////////////////////////////////Back Side///////////////////////////////////////
void gridcheck_back()
{
    int contioun = 0;
    for (int i = 0; i < 4; i++)
    {
        if (point_1[i][0] < 0)
        {
            contioun++;
        }
    }
    if (contioun != 0)
    {
        for (int i = 0; i < 4; i++)
        {
            point_1[i][0] += 1;
        }
        contioun = 0;
    }
}
/////////////////////////////Rotations along the block//////////////////////////////////////////////
void rotation121()
{
    point_1[0][0] -= 2;
    point_1[1][0] -= 1;
    point_1[0][1] += 2;
    point_1[1][1] += 1;
    point_1[3][0] += 1;
    point_1[3][1] -= 1;
}
/////////////////////////////Rotations along the block//////////////////////////////////////////////

void rotation122()
{

    point_1[0][1] -= 2;
    point_1[1][1] -= 1;
    point_1[0][0] += 2;
    point_1[1][0] += 1;
    point_1[3][1] += 1;
    point_1[3][0] -= 1;
}

/////////////////////////////Line removing concept that if all the block in the grid is not///////
/////////////////////////////////zero it will make it zero////////////////////////////////////////

void removing_lines(int chounti, int &count, int &countsd, int fixed, int nanofixed)
{
    if (chounti == 1)
    {
        for (int i = 0; i < 4; i++)
        {
            if (point_1[i][1] < 0)
            {
                break;
            }
        }
        if (gameGrid[fixed][nanofixed] != gameGrid[fixed + 1][nanofixed])
        {
            gameGrid[fixed][nanofixed] = 0;
            gammma[fixed][nanofixed] = 0;
            beeta[fixed][nanofixed] = 0;
            for (int i = 0; i < 3; i++)
            {
                gameGrid[fixed + i][nanofixed] = 0;
                gammma[fixed + i][nanofixed] = 0;
                beeta[fixed + i][nanofixed] = 0;
            }

            if (point_1[1][0] != 9)
            {

                gameGrid[fixed + 1][nanofixed + 1] = 0;
                gameGrid[fixed + 2][nanofixed + 1] = 0;

                gammma[fixed + 1][nanofixed + 1] = 0;
                gammma[fixed + 2][nanofixed + 1] = 0;

                beeta[fixed + 1][nanofixed + 1] = 0;
                beeta[fixed + 2][nanofixed + 1] = 0;
            }
            else
            {
                gameGrid[fixed][nanofixed] = 0;
                gameGrid[fixed + 1][nanofixed - 1] = 0;
                gameGrid[fixed + 2][nanofixed - 1] = 0;

                gammma[fixed][nanofixed] = 0;
                gammma[fixed + 1][nanofixed - 1] = 0;
                gammma[fixed + 2][nanofixed - 1] = 0;

                beeta[fixed][nanofixed] = 0;
                beeta[fixed + 1][nanofixed - 1] = 0;
                beeta[fixed + 2][nanofixed - 1] = 0;
            }

            count = 0;
            countsd = 1;
        }

        else
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    gameGrid[i][j] = 0;
                    gammma[i][j] = 0;
                    beeta[i][j] = 0;
                }
            }
        }
    }
}
/////////////////////////////////////Grid checking row wise////////////////////////////////////
void check_grid(int &check)
{

    for (int i = 0; i < 4; i++)
    {
        if (point_1[i][1] > 19)
        {
            check++;
        }
    }
    if (check != 0)
    {
        for (int i = 0; i < 4; i++)
        {
            point_1[i][1] -= 1;
        }
    }
}
/////////////////////////////////////rotation along the 1st block///////////////////////////
void rotation1s(int &rotation1)
{
    for (int i = 0; 1; i++)
    {
        inbetween(beeta);
        inbetween1(beeta);
        if (rotation1 == 1)
        {
            point_1[1][0] -= 2;
            point_1[1][1] += 2;
            break;
        }
        else if (rotation1 == 2)
        {
            point_1[1][1] -= 2;
            point_1[1][0] -= 1;
            point_1[3][0] -= 1;
            point_1[3][1] -= 2;
            break;
        }
        else if (rotation1 == 3)
        {
            point_1[2][0] -= 2;
            point_1[2][1] -= 2;
            break;
        }
        else if (rotation1 == 4)
        {
            point_1[2][0] += 2;
            point_1[2][1] += 2;
            point_1[1][1] += 2;
            point_1[3][1] += 2;
            point_1[1][0] += 1;
            point_1[3][0] += 1;
            point_1[1][1] -= 2;
            point_1[1][0] += 2;
            for (int i = 0; i < 4; i++)
            {
                point_1[i][0] -= 1;
            }
            break;
        }
        if (rotation1 > 4)
        {
            rotation1 -= 4;
            continue;
        }
    }
}
/////////////////////////////////////rotation along the 2nd block///////////////////////////

void rotation2s(int &rotation2)
{
    for (int i = 0; 1; i++)
    {
        inbetween(beeta);
        inbetween1(beeta);                     
        if (rotation2 == 1)
        {
            point_1[0][0] -= 1;
            point_1[1][0] -= 1;
            point_1[2][1] -= 1;
            point_1[3][1] -= 1;
            point_1[0][1] += 1;
            point_1[1][1] += 1;
            break;
        }
        else if (rotation2 == 2)
        {
            point_1[2][0] -= 2;
            point_1[2][1] += 2;
            break;
        }
        else if (rotation2 == 3)
        {
            point_1[3][0] -= 2;
            point_1[3][1] -= 1;
            point_1[1][1] += 1;
            break;
        }
        else if (rotation2 == 4)
        {
            point_1[3][1] += 2;
            point_1[0][1] -= 1;
            point_1[2][1] -= 1;
            point_1[0][0] -= 1;
            point_1[1][1] -= 2;
            point_1[1][0] -= 1;
            break;
        }
        if (rotation2 > 4)
        {
            rotation2 -= 4;
            continue;
        }
    }
}
/////////////////////////////////////rotation along the 4th block///////////////////////////


void rotation4s(int &rotation4)
{
    for (int i = 0; 1; i++)
    {
        inbetween(beeta);
        inbetween1(beeta);
        if (rotation4 == 1)
        {
            point_1[3][1] -= 2;
            point_1[3][0] -= 2;
            break;
        }
        else if (rotation4 == 2)
        {
            point_1[3][1] += 2;
            point_1[3][0] += 2;
            point_1[0][0] += 1;
            point_1[3][0] -= 1;
            break;
        }
        else if (rotation4 == 3)
        {
            point_1[3][0] += 2;
            point_1[3][1] -= 2;
            break;
        }
        else if (rotation4 == 4)
        {
            point_1[0][0] -= 1;
            point_1[3][1] += 2;
            point_1[3][0] -= 1;
            break;
        }
        if (rotation4 > 4)
        {
            rotation4 -= 4;
            continue;
        }
    }
}

/////////////////////////////////////rotation along the 5th block///////////////////////////

void rotation5s(int &nextrotation)
{
    for (int i = 0; 1; i++)
    {
        if (nextrotation == 1)
        {
            point_1[1][0] += 2;
            point_1[3][0] += -1;
            point_1[3][1] += -1;
            point_1[0][1] += 2;
            break;
        }
        if (nextrotation == 2)
        {
            point_1[1][0] -= 2;
            point_1[3][0] += 1;
            point_1[3][1] += 1;
            point_1[0][1] -= 2;
            break;
        }
        if (nextrotation > 2)
        {
            nextrotation -= 2;
            continue;
        }
    }
}
/////////////////////////////////////rotation along the 6th block///////////////////////////

void rotation6s(int &rotationno)
{
    for (int i = 0; 1; i++)
    {
        inbetween(beeta);
        inbetween1(beeta);
        if (rotationno == 1)
        {
            point_1[3][0] += -1;
            point_1[3][1] += -1;
            break;
        }
        ////////////////////
        else if (rotationno == 2)
        {
            point_1[3][0] += 1;
            point_1[3][1] += 1;
            break;
        }
        ///////////////////

        if (rotationno > 2)
        {
            rotationno -= 2;
            continue;
        }
    }
}

/////////////////////////////////////rotation along the 0th block///////////////////////////

void rotation0s(int &rotation0)
{
    for (int i = 0; 1; i++)
    {
        inbetween(beeta);
        inbetween1(beeta);

        if (rotation0 == 1)
        {
            rotation121();
            break;
        }
        else if (rotation0 == 2)
        {
            rotation122();

            break;
        }
        if (rotation0 > 2)
        {
            rotation0 -= 2;
            continue;
        }
    }
}
/////////////////////////////////////line removing concept///////////////////////////////////////

void check(int &counto, int i, int &zeeta, int &beta, int &checkit)
{
    if (counto == 10)
    {

        alpha = 19 - i;
        zeeta = 19 - alpha;
        cout << zeeta << endl
             << endl;

        beta = 19 - alpha;
        checkit++;
    }

    if (counto == 10)
    {

        for (int lm = zeeta; lm > 0; lm--)
        {
            for (int j = 0; j < 10; j++)
            {
                if (gameGrid[lm][j] != 0)
                {
                    gameGrid[lm][j] = 0;
                }
                gammma[lm][j] = 0;
                beeta[lm][j] = 0;
            }
            for (int p = 0; p < 10; p++)
            {
                gameGrid[lm][p] = gameGrid[lm - 1][p];
            }
        }
        counto = 0;
    }

    else
    {
        counto = 0;
    }
    counto = 0;
}

////////////////////////////////For Shdow Bool is used to exceed the value by 1 along the row comp///

int pass()
{
    for (int i = 0; i < 4; i++)
    {
        if (gameGrid[point_5[i][1] + 1][point_5[i][0]] || point_5[i][1] + 1 >= 20)
        {
            return 0;
        }
    }
    return 1;
}