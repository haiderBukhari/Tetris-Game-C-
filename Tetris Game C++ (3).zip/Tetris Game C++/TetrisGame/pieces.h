/*
Name: Muhammad Haider Bukhari
Section CS-K
Roll NO 22I-0980
Project
*/
/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)


 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */

// void to_1strotate(int &rotation)
// {

//     for (int i = 0; i < 4; i++)
//     {
//         int temp = point_1[i][0];
//         point_1[i][0] = point_1[i][1];
//         point_1[i][1] = temp;
//     }
// }

// // void to_2ndrotate(int &rotation)
// {
//     for (int i = 0; i < 4; i++)
//     {
//         int temp = point_1[i][1];
//         point_1[i][1] = point_1[i][0];
//         point_1[i][0] = temp;
//     }
// }